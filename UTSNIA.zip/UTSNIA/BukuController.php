<?php

namespace App\Http\Controllers;

use App\Models\Buku;
use Illuminate\Http\Request;

class BukuController extends Controller
{
    // Menampilkan daftar buku
    public function index()
    {
        $buku = Buku::all(); // atau paginate jika kamu ingin pagination
        return view('buku', compact('buku'));
    }
   

    // Menampilkan form untuk menambah buku
    // Menampilkan form untuk menambah buku
    public function create() {
        return view('buku.create');
    }

    // Menyimpan buku ke database
    public function store(Request $request) {
        $validated = $request->validate([
            'judul' => 'required|string',
            'pengarang' => 'required|string',
            'tahun' => 'required|numeric',
            'penerbit' => 'nullable|string',
            'kategori' => 'nullable|string',
        ]);
    
        Buku::create($validated);
    
        return redirect()->route('home')->with('success', 'Buku berhasil ditambahkan');
    }
    


    // Menampilkan form untuk mengedit buku
    public function edit($id)
    {
        $buku = Buku::findOrFail($id);
        return view('buku.edit', compact('buku'));
    }
    
    // Mengupdate data buku
    public function update(Request $request, $id) {
        $validated = $request->validate([
            'judul' => 'required|string',
            'penulis' => 'required|string',
            'tahun_terbit' => 'required|numeric',
        ]);

        $buku = Buku::findOrFail($id);
        $buku->update($validated);
        return redirect()->route('buku.index');
    }

    // Menghapus data buku
    public function destroy($id) {
        Buku::destroy($id);
        return redirect()->route('buku.index');
    }

}
